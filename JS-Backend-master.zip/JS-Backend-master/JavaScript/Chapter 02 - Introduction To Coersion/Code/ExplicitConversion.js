console.log(Boolean(""));
console.log(String(123));