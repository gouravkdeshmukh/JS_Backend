let x = 10;
console.log(!x);
let y = undefined;
console.log(!y);

if(y) {
    console.log("It is truthy");
} else {
    console.log("It is falsy");
}