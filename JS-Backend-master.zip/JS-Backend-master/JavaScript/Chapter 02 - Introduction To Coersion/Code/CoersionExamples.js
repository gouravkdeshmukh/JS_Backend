console.log(1 < 2 < 3);// -> (1 < 2) = true -> true < 3 -> 1 < 3 -> true
console.log(3 > 2 > 1);// -> (3 > 2) -> true -> true > 1 -> 1 > 1 -> false

let obj = {x: 10, y: 20};
let num = 10;
console.log(`My object is ${obj}`);
console.log("My object is"+obj);