let obj = {};

console.log(obj);

console.log("18" + obj); // "18" "[object Object]" -> "18[object Object]"

console.log(18 + obj); // 18 "[object Object]" ->