// const x = 10;
// x = 9;

// const obj = {x: 10};
// obj.y = 9;

// obj = {};

// const y;