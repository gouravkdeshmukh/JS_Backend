"use strict";
{
    function fun() {
        return "123";
    }
    console.log(fun);
}

console.log(fun);