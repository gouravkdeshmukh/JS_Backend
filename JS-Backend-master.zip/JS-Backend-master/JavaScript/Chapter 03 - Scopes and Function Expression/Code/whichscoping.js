// var teacher = "Sanket"; 
// function ask(question) { 
// 	console.log(teacher, question); 
// }

// function fun() { 
// 	var teacher = "Pulkit"; 
// 	ask("why?");
// }
// fun();
var fun;
function fun() {
    return 'fun2';
}

console.log(fun);