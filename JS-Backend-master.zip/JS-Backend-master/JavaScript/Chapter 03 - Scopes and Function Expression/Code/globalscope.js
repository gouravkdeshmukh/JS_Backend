var name = "Sanket";
function fun() {
    console.log(name);
}
fun();
console.log(name);