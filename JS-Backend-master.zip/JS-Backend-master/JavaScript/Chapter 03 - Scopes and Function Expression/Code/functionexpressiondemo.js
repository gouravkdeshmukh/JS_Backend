let x = function () {
    console.log('HI');
}
console.log(x);
x();