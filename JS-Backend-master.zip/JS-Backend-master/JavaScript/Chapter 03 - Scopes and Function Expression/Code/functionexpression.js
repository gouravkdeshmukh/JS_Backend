function fun() { // function declaration
    // some impl
}

let f = function gun() { // named function expression
    // some impl
}

let a = function() { // anonymous function expression
    // okk some more impl
}

(function x() {
    // can you stop it ?
}) // function expression

(function (){
    // i am done
})

let y = () => {

}