console.log(content);
content = "JS";