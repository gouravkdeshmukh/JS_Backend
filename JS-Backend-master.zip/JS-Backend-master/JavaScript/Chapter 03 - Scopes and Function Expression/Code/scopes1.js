var teacher = "Sanket";
function fun() {
    var teacher = "Pulkit";
    console.log(teacher);
}
function gun() {
    var student = "Sarthak";
    console.log(student);
}

fun();
gun();
console.log(teacher);


