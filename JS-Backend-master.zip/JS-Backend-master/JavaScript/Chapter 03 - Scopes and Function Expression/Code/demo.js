console.log("hi");
// console = {lo: function(str) {}}
// console.lo("hello");
console.log("bye");

console.log(5..toString(2));


console.log("hi");
console..log("hello");
console.log("bye");