"use strict";
var teacher = "Sanket";
function fun() {
    var teacher = "Pulkit";
    // content = "JS";
    console.log(teacher);
    // console.log(content);
}
function gun() {
    var student = "Sarthak";
    console.log(student);
}
fun();
gun();
console.log(teacher);
// console.log(content);



const o = { p: 1, p: 2 };