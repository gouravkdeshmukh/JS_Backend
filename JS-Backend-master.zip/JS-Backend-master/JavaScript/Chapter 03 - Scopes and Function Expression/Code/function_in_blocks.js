{
    function fun() {
        return "123";
    }
}

console.log(fun);