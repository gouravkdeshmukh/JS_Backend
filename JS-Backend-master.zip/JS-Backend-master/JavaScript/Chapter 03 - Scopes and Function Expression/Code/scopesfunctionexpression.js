const f = function fun() {
    console.log("How much fun????");
}

console.log(f());
// fun();s