setTimeout(function exec() {
    console.log("Running after sometime")
} , 4000);



nameofthefunction()