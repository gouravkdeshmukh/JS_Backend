console.log("Hi we are starting");

for(let i = 0; i < 10000000000; i++) {
    // some task
}

console.log("Done");