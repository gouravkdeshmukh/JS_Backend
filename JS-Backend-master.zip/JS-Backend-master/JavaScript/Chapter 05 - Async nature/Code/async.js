console.log("hi");
setTimeout(function () { console.log("time done"); });
console.log("by");